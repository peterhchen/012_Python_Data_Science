from tkinter import *
import tkinter

top = tkinter.Tk()
B1 = tkinter.Button(top, text ="arrow", relief=RAISED,\
                         cursor="arrow")
B2 = tkinter.Button(top, text ="circle", relief=RAISED,\
                         cursor="circle")
B3 = tkinter.Button(top, text ="plus", relief=RAISED,\
                         cursor="plus")
B4 = tkinter.Button(top, text ="fleur", relief=RAISED,\
                         cursor="fleur")
B5 = tkinter.Button(top, text ="spraycan", relief=RAISED,\
                         cursor="spraycan")
B6 = tkinter.Button(top, text ="tcross", relief=RAISED,\
                         cursor="tcross")
B7 = tkinter.Button(top, text ="trek", relief=RAISED,\
                         cursor="trek")
B8 = tkinter.Button(top, text ="watch", relief=RAISED,\
                         cursor="watch")
B1.pack()
B2.pack()
B3.pack()
B4.pack()
B5.pack()
B6.pack()
B7.pack()
B8.pack()
top.mainloop()