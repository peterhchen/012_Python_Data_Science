from tkinter import *
try:
    from tkinter import messagebox
except ImportError:
    # Python 2
    import tkMessageBox as messagebox
import tkinter

top = tkinter.Tk()

def helloCallBack():
   messagebox.showinfo ("Hello Python", "Hello World")

B = tkinter.Button(top, text ="Hello", command = helloCallBack)

B.pack()
B.place(bordermode=OUTSIDE, height=100, width=150)
top.mainloop ()