#!/usr/bin/python
a = 21; b = 10; c = 0
print('a =', a, '; b =', b, '; c =', c)
c = a + b
print('c = a + b; c =', c)
print('a =', a, '; c =', c)
c += a
print('c += a; c =', c)
print('a =', a, '; c =', c)
c *= a
print('c *= a; c=', c)
print('a =', a, '; c =', c)
c /= a 
print('c /= a; c=', c)
print()

c  = 2
print('a =', a, '; c =', c)
c %= a
print('c %= a; c =', c)
print('a =', a, '; c =', c)
c **= a
print('c **= a;  c =', c)
print('a =', a, '; c =', c)
c //= a
print('c //= a; c =', c)