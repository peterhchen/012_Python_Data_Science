a = b = c = 1
print('a:', a, 'b:', b, 'c:', c)

a,b,c = 1,2,"john"
print('a:', a, 'b:', b, 'c:', c)