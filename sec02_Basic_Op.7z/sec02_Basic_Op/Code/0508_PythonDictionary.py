#!/usr/bin/python

dict = {}
dict['one'] = "This is one"
dict[2]     = "This is two"

tinydict = {'name': 'john','code':6734, 'dept': 'sales'}


print("dict['one']:", dict['one'])              # Prints value for 'one' key
print('dict[2]:', dict[2])                      # Prints value for 2 key
print('tinydict:', tinydict)                    # Prints complete dictionary
print('tinydict.keys():', tinydict.keys())      # Prints all the keys
print('tinydict.values():', tinydict.values())  # Prints all the values