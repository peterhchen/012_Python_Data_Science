#!/usr/bin/python
# run with ./0403_ScriptInterpreter.py
print("Hello, Python: Script Interpreter")
