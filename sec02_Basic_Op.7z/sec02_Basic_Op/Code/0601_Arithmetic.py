#!/usr/bin/python
a = 21; b = 10; c = 0
print("a =", a, '; b =', b, '; c =', c)
c = a + b
print("c = a + b =", c)
c = a - b
print("c = a - b =", c)
c = a * b
print("c = a * b = ", c) 
c = a / b
print("c = a / b =", c) 
c = a % b
print("c = a % b =", c) 
a = 2; b = 3; c = a**b
print("a =", a, '; b =', b)
print('c = a ** b = ', c)
a = 10; b = 5; c = a//b 
print("a =", a, '; b =', b)
print('c = a//b =', c)