#!/usr/bin/python
a = 21; b = 10; c = 0
if (a == b):
    print ('if (a == b):', 'a =', a, '; b =', b)
else:
    print ('if (a == b) else:', 'a =', a, '; b =', b)
if (a != b):
    print("if (a != b):", 'a =', a, '; b =', b)
else:
    print("if (a !=b) else:", 'a =', a, '; b=', b)   
if (a < b):
    print("if (a <b):", 'a =', a, '; b =', b)
else:
    print("if (a < b) else:", 'a =', a, '; b =', b)
if (a > b):
    print("if (a > b):", 'a =', a, '; b =', b)
else:
    print("if (a > b) else:", 'a =', a, '; b =', b)
a = 5;
b = 20;
if (a <= b):
    print("if (a <= b):", 'a =', a, '; b =', b)
else:
    print("if (a <=b) else:", 'a =', a, '; b =', b) 
if ( b >= a ):
    print("if (b >= a):", 'a =', a, '; b =', b)
else:
    print("if (b >= a) else:", 'a =', a, '; b =', b)