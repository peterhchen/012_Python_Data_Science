#!/usr/bin/python
a = 60            # 60 = 0011 1100 
b = 13            # 13 = 0000 1101 
c = 0
print('a =', a, '; bin(a) =', bin(a)[2:].zfill(8))
# 0b111100 => 
# [2:] = 111100 => 
# zfill(8) = 00111100
print("b =", b, '; bin(b) =', bin(b)[2:].zfill(8))
print('c =', c, '; bin(c) =', bin(c)[2:].zfill(8)); print()
c = a & b;        # 12 = 0000 1100
print('bin(a) =', bin(a)[2:].zfill(8), 'bin(b) =', bin(b)[2:].zfill(8))
print('c = a & b; c =', c, '; bin(c)[2:].zfill(8) =', bin(c)[2:].zfill(8))
c = a | b;        # 61 = 0011 1101
print('bin(a)[2:].zfill(8) =', bin(a)[2:].zfill(8), 'bin(b) =', bin(b)[2:].zfill(8))
print ('c = a | b; c =', c, '; bin(c)[2:].zfill(8) =', bin(c)[2:].zfill(8))
c = a ^ b;        # 49 = 0011 0001
print('bin(a)[2:].zfill(8) =', bin(a)[2:].zfill(8), 'bin(b) =', bin(b)[2:].zfill(8))
print('c = a ^ b; c =', c, '; bin(c)[2:].zfill(8) =', bin(c)[2:].zfill(8))
c = ~a;           # -61 = 1100 0011
print('bin(a)[2:].zfill(8) =', bin(a)[2:].zfill(8))
print ('c = ~a; c =', c, '; bin(c) =', bin(c)[2:].zfill(8))
c = a << 2;       # 240 = 1111 0000
print('bin(a)[2:].zfill(8) =', bin(a)[2:].zfill(8))
print('c = a << 2; c =', c, '; bin(c) =', bin(c)[2:].zfill(8))
c = a >> 2;       # 15 = 0000 1111
print('bin(a)[2:].zfill(8) =', bin(a)[2:].zfill(8))
print('c = a >> 2; c =', c, '; bin(c)[2:].zfill(8) =', bin(c)[2:].zfill(8))