#!/usr/bin/python

counter = 100          # An integer assignment
miles   = 1000.0       # A floating point
name    = "John"       # A string

print('counter:', (counter))
print('miles:', miles)
print('name:', name)

# a and b are same value. Same address
a = 100
b = a
print("b = a => a:", a)
print('b = a => b:', b)
print('address id(a):', id(a))
print('address id(b):', id(b))
print('address hex(id(a)):', hex(id(a)))
print('address hex(id(b)):', hex(id(b)))
del a
# print("a:", a)
# NameError: name 'a' is not defined
print('b:', b)
# print('address hex(id(a)):', hex(id(a)))
# NameError: name 'a' is not defined
print('address hex(id(b)):', hex(id(b)))
# Same value has same address
c = 100
d = 100
print('address c:', c)
print('address d:', d)
print('address id(c):', id(c))
print('address id(d)):', id(d))
# different values have different addresses
e = 100
f = 200
print('address c:', e)
print('address d:', f)
print('address id(c):', id(e))
print('address id(d)):', id(f))
# counter: 100
# miles: 1000.0
# name: John
# b = a => a: 100
# b = a => b: 100
# address id(a): 140733903580656
# address id(b): 140733903580656
# address hex(id(a)): 0x7fff2a54adf0
# address hex(id(b)): 0x7fff2a54adf0
# b: 100
# address hex(id(b)): 0x7fff2a54adf0
# address c: 100
# address d: 100
# address id(c): 140733903580656
#address id(d)): 140733903580656
# address c: 100
# address d: 200
# address id(c): 140733903580656
# address id(d)): 140733903583856