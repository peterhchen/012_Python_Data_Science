#!/usr/bin/python

counter = 100          # An integer assignment
miles   = 1000.0       # A floating point
name    = "John"       # A string

print('counter:')
print(counter)
print('miles:')
print(miles)
print('name:')
print(name)