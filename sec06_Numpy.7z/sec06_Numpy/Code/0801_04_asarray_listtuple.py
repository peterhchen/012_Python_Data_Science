# ndarray from list of tuples 
import numpy as np 

x = [(1,2,3),(4,5)] 
# Need to specify the dtype = object
a = np.asarray(x, dtype=object) 
print('a:')
print(a)
# a:
# [(1, 2, 3) (4, 5)]