# https://numpy.org/doc/stable/reference/generated/numpy.frombuffer.html
import numpy as np 
s = b'Hello World'
a = np.frombuffer(s, dtype = 'S1', count=5, offset=6) 
print('a:', a)
# a: [b'W' b'o' b'r' b'l' b'd']