import numpy as np 
x = np.empty([3,2], dtype = int) 
print('x:')
print(x)
# x:
#[[7209065 4390971]
# [6029370 7471184]
# [6750319 6357106]]