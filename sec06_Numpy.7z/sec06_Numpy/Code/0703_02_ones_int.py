import numpy as np 
x = np.ones([2,2], dtype = int) 
print('x:')
print(x)
# x:
# [[1 1]
# [1 1]]