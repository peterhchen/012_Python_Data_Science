# find retstep value 
import numpy as np 

x = np.linspace(1, 2, 5, retstep = True) 
# start = 1, stop = 2, num = 5
# retstep retruns array with sample =5 and step is 0.25
print('x:', x) 
# x: (array([1.  , 1.25, 1.5 , 1.75, 2.  ]), 0.25)