import numpy as np
a = np.arange(0, 60, 5)
print('a:', a)
# a: [ 0  5 10 15 20 25 30 35 40 45 50 55]
a = a.reshape(3,4)
print('a = a.reshape(3,4):')
print(a)
# a = a.reshape(3,4):
# a:
#[[ 0  5 10 15]
# [20 25 30 35]
# [40 45 50 55]]

b = a.T
print('After transpose a:')
print(a)
# After transpose a:
# [[ 0  5 10 15]
# [20 25 30 35]
#  [40 45 50 55]]
print('b:')
print(b)
# b:
# [[ 0 20 40]
# [ 5 25 45]
# [10 30 50]
# [15 35 55]]

c = b.copy(order = 'C')
print("c = b.copy(order = 'C')")
print(c)
# c = b.copy(order = 'C')
# [[ 0 20 40]
#  [ 5 25 45]
#  [10 30 50]
#  [15 35 55]]
print('print by iterator after C-style sorting:')
for x in np.nditer(c):
   print(x, end=" ")
print()
# print by iterator after C-style sorting:
# 0 20 40 5 25 45 10 30 50 15 35 55

print("c = b.copy(order = 'F')")
c = b.copy(order = 'F')
print(c)
# c = b.copy(order = 'F')
# [[ 0 20 40]
#  [ 5 25 45]
#  [10 30 50]
#  [15 35 55]]
print('print by iterator after F-style sorting:')
for x in np.nditer(c):
   print(x, end=" ")
# print by iterator after F-style sorting:
# 0 5 10 15 20 25 30 35 40 45 50 55