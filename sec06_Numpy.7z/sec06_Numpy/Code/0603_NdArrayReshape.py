import numpy as np 
a = np.array([[1,2,3],[4,5,6]])
print('original a:')
print(a)
print()
b = a.reshape(3,2) 
print('Reshape b:')
print(b)