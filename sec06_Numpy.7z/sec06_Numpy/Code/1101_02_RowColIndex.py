import numpy as np 
x = np.array([[0,  1,  2], [3,  4,  5], [6,  7,  8], [9, 10, 11]]) 
   
print('x:') 
print(x) 
# x:
# [[ 0  1  2]
#  [ 3  4  5]
#  [ 6  7  8]
# [ 9 10 11]]
rows = np.array([[0,0],[3,3]])
cols = np.array([[0,2],[0,2]])
print('rows:')
print(rows)
# rows:
# [[0 0]
#  [3 3]]
print('cols:')
print(cols)
# cols:
# [[0 2]
#  [0 2]]
y = x[rows,cols] 
# (0, 0) => 0, (0, 2) => 2
# (3, 0) => 9, (3, 2) => 11
print('y:') 
print(y)
# y:
# [[ 0  2]
#  [ 9 11]]