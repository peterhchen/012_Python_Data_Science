# ndarray from tuple 
import numpy as np 

x = (1,2,3) 
a = np.asarray(x) 
print('a:', a)
# the tuple is converted into a list (array)
# a: [1 2 3]