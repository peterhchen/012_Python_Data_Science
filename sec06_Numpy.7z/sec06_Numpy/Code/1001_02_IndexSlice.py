import numpy as np 
a = np.arange(10)
print('a:', a)
# a: [0 1 2 3 4 5 6 7 8 9]
b = a[2:7:2] 
# start index = 2, stop index = 7 (open bracket, stop at index = 6)
# We have => [2, 3, 4, 5, 6]
# step with 2 => [2, 4, 6] is the answer
print('b:', b)
# b: [2 4 6]