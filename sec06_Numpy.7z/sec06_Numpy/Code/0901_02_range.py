import numpy as np 
# dtype set 
x = np.arange(5, dtype = float)
print('x:', x)
# x: [0. 1. 2. 3. 4.]