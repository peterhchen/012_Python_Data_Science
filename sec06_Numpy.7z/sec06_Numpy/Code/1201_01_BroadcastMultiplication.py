import numpy as np 

a = np.array([1,2,3,4]) 
b = np.array([10,20,30,40]) 
print('a =', a)
print('b =', b)
c = a * b 
print('c = a * b =>', c)
# a = [1 2 3 4]
# b = [10 20 30 40]
# c = a * b => [ 10  40  90 160]