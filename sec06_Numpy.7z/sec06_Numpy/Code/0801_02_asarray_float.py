# dtype is set 
import numpy as np 

x = [1,2,3]
a = np.asarray(x, dtype = float) 
print('a:', a)
# a: [1. 2. 3.]