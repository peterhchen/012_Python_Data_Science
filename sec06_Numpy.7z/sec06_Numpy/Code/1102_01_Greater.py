import numpy as np 
x = np.array([[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11]]) 
print('x:') 
print(x)
# x:
# [[ 0  1  2]
# [ 3  4  5]
# [ 6  7  8]
# [ 9 10 11]]

# Now we will print the items greater than 5 
print('x[x>5] =>')
print(x[x > 5])

# x[x>5] =>
# [ 6  7  8  9 10 11]