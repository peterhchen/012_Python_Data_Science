# first create structured data type 
import numpy as np 
dt = np.dtype([('age',np.int8)])
print('dt:')
print(dt)