# array to begin with 
import numpy as np 
a = np.array([[1,2,3],[3,4,5],[4,5,6]]) 
print('a:') 
print(a, '\n') 
#a:
#[[1 2 3]
# [3 4 5]
# [4 5 6]]

print('a[0] =>', a[0]) 
print('a[1] =>', a[1]) 
print('a[2] =>', a[2], '\n') 
# a[0] => [1 2 3]
# a[1] => [3 4 5]
#a[2] => [4 5 6]
print('a[0][0] =>', a[0][0]) 
print('a[1][0] =>', a[1][0]) 
print('a[2][0] =>', a[2][0], '\n')
# a[0][0] => 1
# a[1][0] => 3
# a[2][0] => 4
 
print('First column are a[...,0] =>', a[...,0]) 
print('Second column are a[...,1] =>', a[...,1])  
print('Third column are a[...,2] =>', a[...,2], '\n') 
# First column are a[...,0] => [1 3 4]
# Second column are a[...,1] => [2 4 5]
# Third column are a[...,2] => [3 5 6]

print('First row are a[1,...] =>', a[0,...])
print('Second row are a[1,...] =>', a[1,...]) 
print('Third row are a[2,...] =>', a[2,...], '\n') 
# First row are a[1,...] => [1 2 3]
# Second row are a[1,...] => [3 4 5]
# Third row are a[2,...] => [4 5 6]

# Column 1 to end (column 2) 
print('Column 1 to end (column 2) are a[..., 1:] =>') 
print(a[..., 1:])
# [[2 3]
# [4 5]
# [5 6]]