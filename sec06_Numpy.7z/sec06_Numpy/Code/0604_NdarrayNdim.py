# an array of evenly spaced numbers 
import numpy as np 
a = np.arange(24)
print('a:')
print(a)