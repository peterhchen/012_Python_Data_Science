import numpy as np
a = np.arange(0,60,5)
a = a.reshape(3,4)
print('a:')
print(a)
# a:
# [[ 0  5 10 15]
#  [20 25 30 35]
#  [40 45 50 55]]
print('Modified array by nditer with op_flags:')
for x in np.nditer(a, op_flags = ['readwrite']):
   x[...] = 2*x
print('a:')
print(a)

# Modified array by nditer with op_flags:
# a:
# [[  0  10  20  30]
#  [ 40  50  60  70]
#  [ 80  90 100 110]]