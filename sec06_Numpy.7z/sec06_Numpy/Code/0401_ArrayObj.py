
"""
File Name: test.py
"""

import numpy as np
A1 = np.array([1, 2, 3])
print('A1:')
print(A1)
