# using endian notation 
import numpy as np 
dt = np.dtype('>i4')
print('dt:')
print(dt)