# set base of log space to 2 
import numpy as np 
a = np.logspace(1, 10, num = 10, base = 2) 
# start = 2^1 = 2, stop = 2^10 = 1024
print('a:')
print(a)
# a:
# [   2.    4.    8.   16.   32.   64.  128.  256.  512. 1024.]