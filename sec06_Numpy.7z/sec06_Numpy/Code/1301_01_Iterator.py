import numpy as np
# start 0, stop = 59, step = 5
a = np.arange(0, 60, 5)
print('a =', a)
# a = [ 0  5 10 15 20 25 30 35 40 45 50 55]
a = a.reshape(3,4)
print('a = a.reshape(3, 4)=>')
print(a)
# a = a.reshape(3, 4)=>
# [[ 0  5 10 15]
#  [20 25 30 35]
#  [40 45 50 55]]

print('Iterator (a) =>')
for x in np.nditer(a):
   print(x, end = " ")
# Iterator (a) =>
# 0 5 10 15 20 25 30 35 40 45 50 55