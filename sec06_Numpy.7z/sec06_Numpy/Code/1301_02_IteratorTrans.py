import numpy as np 
a = np.arange(0, 60, 5) 
print('a:', a)
# a: [ 0  5 10 15 20 25 30 35 40 45 50 55]
a = a.reshape(3, 4) 
print('a = a.reshape(3, 4) =>')
print(a)
# a = a.reshape(3, 4) =>
# [[ 0  5 10 15]
#  [20 25 30 35]
#  [40 45 50 55]]   

print('Iterator of a before transpose =>') 
for x in np.nditer(a): 
   print(x, end=" ")
print()
# Iterator of a before transpose =>
# 0 5 10 15 20 25 30 35 40 45 50 55

b = a.T 
print('Transpose of the original array is:')
print('b = a.T =>')
print(b)
# Transpose of the original array is:
# b = a.T =>
# [[ 0 20 40]
#  [ 5 25 45]
#  [10 30 50]
#  [15 35 55]]  

print('Iterator of a after transpose =>') 
for x in np.nditer(a): 
   print(x, end=" ")
print()
# Iterator of a after transpose =>
# 0 5 10 15 20 25 30 35 40 45 50 55   

print('Iterator of b after transpose =>') 
for x in np.nditer(b): 
   print(x, end=" ")
# Iterator of b after transpose =>
# 0 5 10 15 20 25 30 35 40 45 50 55