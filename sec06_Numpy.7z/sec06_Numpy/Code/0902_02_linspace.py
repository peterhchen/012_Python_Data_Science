# endpoint set to false 
import numpy as np 

# Exclude the end point
x = np.linspace(10, 20, 5, endpoint = False) 
print('x:', x)
# x: [10. 12. 14. 16. 18.]

# Include endpoint
y = np.linspace(10, 20, 5) 
print('y:', y)
# y: [10.  12.5 15.  17.5 20. ]