# array of five ones. Default dtype is float 
import numpy as np 
x = np.ones(5) 
print('x:', x)
# x: [1. 1. 1. 1. 1.]