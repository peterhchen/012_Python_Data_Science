# create list object using range function 
import numpy as np 
list = list(range(5)) 
print('list:', list)
# list: [0, 1, 2, 3, 4]

it = iter(list)  

# use iterator to create ndarray 
x = np.fromiter(it, dtype = float) 
print ('x:', x)
# x: [0. 1. 2. 3. 4.]