# slice items starting from index 
import numpy as np 
a = np.arange(10) 
print('a:', a)
# a: [0 1 2 3 4 5 6 7 8 9]
print('a[2:]:', a[2:])
# start from index = 2
# a[2:]: [2 3 4 5 6 7 8 9]