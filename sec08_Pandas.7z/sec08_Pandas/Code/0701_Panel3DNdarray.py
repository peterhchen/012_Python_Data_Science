# creating an empty panel
import pandas as pd
import numpy as np

# Dimensions: 5 columns x 3 rows x 2 tiems = 30 itmes
data = np.random.rand(5, 3, 2)
"""
df:
           item 1    item 2    item 3    item 4    item 5
2015 US  0.445125  0.332490  0.255212  0.138160  0.860343
     UK  0.127950  0.765258  0.010467  0.383336  0.638694
2016 US  0.037505  0.007167  0.073646  0.080115  0.408899
     UK  0.781076  0.024178  0.740676  0.363926  0.534625
2017 US  0.787586  0.021411  0.013219  0.530241  0.715769
     UK  0.233562  0.657889  0.065708  0.800715  0.160003
"""
data = data.reshape(5, 6).T   # col x row
# df.Panel(data)
# is deprecated. Use DataFrame and MultiIndex instead.
df = pd.DataFrame(
    data=data,
    index=pd.MultiIndex.from_product([[2015, 2016, 2017], ['US', 'UK']]),
    # item1 to item5: rnage (1, 6)
    columns=['item {}'.format(i) for i in range(1, 6)]
)
print('df:')
print(df)

data = np.random.rand(2,3,2)
# Dimensions: 2 (items) x 3 (major_axis) x 2 (minor_axis) = total 12 items.
"""
df:
           item 1    item 2
2015 US  0.445125  0.332490
     UK  0.127950  0.765258 
2016 US  0.037505  0.007167 
     UK  0.781076  0.024178 
2017 US  0.787586  0.021411 
     UK  0.233562  0.657889  
"""
data = data.reshape(2, 6).T
df = pd.DataFrame(
    data=data,
    index=pd.MultiIndex.from_product([[2015, 2016, 2017], ['US', 'UK']]),
    # item1 to item2: range (1, 3)
    columns=['item {}'.format(i) for i in range(1, 3)]
)
print('df:')
print(df)