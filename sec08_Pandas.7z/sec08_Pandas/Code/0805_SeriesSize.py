import pandas as pd
import numpy as np

#Create a series with 4 random numbers
s = pd.Series(np.random.randn(2))
print('s:')
print(s)
print()
print ("The size of the object:")
print('s.size:')
print(s.size)