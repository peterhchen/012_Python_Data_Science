Test for git.
