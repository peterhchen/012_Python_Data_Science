# import the pandas library
import pandas as pd
left = pd.DataFrame({
         'id':[1,2,3,4,5],
         'Name': ['Alex', 'Amy', 'Allen', 'Alice', 'Ayoung'],
         'subject_id1':['sub1','sub2','sub4','sub6','sub5']})
right = pd.DataFrame(
         {'id':[1,2,3,4,5],
         'Name': ['Billy', 'Brian', 'Bran', 'Bryce', 'Betty'],
         'subject_id2':['sub2','sub4','sub3','sub6','sub5']})
print ('left:')
print (left)
print ()
print ('right:')
print (right)
print()
merge = left.merge(right, left_on='subject_id1', right_on='subject_id2')
print ('merge:')
print (merge)