import unittest

def div(a,b):
   return a/b

class raiseTest(unittest.TestCase):
   def testraise1(self):
      self.assertRaises(ZeroDivisionError, div, 1, 0)

   def testraise2(self):
      self.assertRaises(ZeroDivisionError, div, 1, 1)

if __name__ == '__main__':
   unittest.main()