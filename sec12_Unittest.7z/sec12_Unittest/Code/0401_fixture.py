import unittest

class simpleTest2(unittest.TestCase):
   def setUp(self):
      print('def setup...')
      self.a = 10
      self.b = 20
      name = self.shortDescription()
      print('name: ', name)
      if name == "Add":
         #print('if name == Add...')
         self.a = 10
         self.b = 20
         print(name, self.a, self.b)
      if name == "sub":
         #print('if name == sub...')
         self.a = 50
         self.b = 60
         print(name, self.a, self.b)

   def tearDown(self):
      print('def tearDown...')
      print('\nend of test',self.shortDescription())

   def testadd(self):
      """Add"""
      print('def testadd...')
      result = self.a+self.b
      self.assertTrue(result == 100)

   def testsub(self):
      """sub"""
      print('def testsub...')
      result = self.a-self.b
      self.assertTrue(result == -10)
      
if __name__ == '__main__':
   print('unittest.main()...')
   unittest.main()