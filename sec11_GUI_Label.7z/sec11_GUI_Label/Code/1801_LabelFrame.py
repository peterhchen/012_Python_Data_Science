from tkinter import *

root = Tk()

labelframe = LabelFrame(root, text="LabelFrame")
labelframe.pack(fill="both", expand="yes")
 
left = Label(labelframe, text="This is the Frame \n under the LabelFrame")
left.pack()
 
root.mainloop()