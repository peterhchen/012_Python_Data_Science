from tkinter import *

root = Tk()

#root.mainloop()
top = Toplevel()
top.mainloop()