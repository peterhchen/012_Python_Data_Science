from tkinter import *

root = Tk()
root.geometry('200x150')
var = StringVar()
msg = Message(root, textvariable=var, relief=RAISED, width=300)

var.set("Message")
msg.pack(padx=50, pady=50)
root.mainloop()