from tkinter import *

top = Tk()
top.geometry('200x150')
var = StringVar()
label = Label(top, textvariable=var, relief=RAISED )
label.pack(padx=20, pady=15, side=LEFT)
var.set("Hi, Label widget")
label.pack()

Lb1 = Listbox(top)
Lb1.insert(1, "Python")
Lb1.insert(2, "Perl")
Lb1.insert(3, "C")
Lb1.insert(4, "PHP")
Lb1.insert(5, "JSP")
Lb1.insert(6, "Ruby")

Lb1.pack()
top.mainloop()