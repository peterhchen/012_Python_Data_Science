from tkinter import *

top = Tk()
top.geometry('200x150')
top.columnconfigure(0, weight=1)
top.columnconfigure(1, weight=3)
label = Label(top, text="Label")
label.grid(column=0, row=0, sticky=W, padx=20, pady=50)
# pack(), place(), grid()

mb =  Menubutton (top, text="condiments", relief=RAISED)
mb.menu =  Menu (mb, tearoff = 0)
mb["menu"] =  mb.menu

mayoVar = IntVar()
ketchVar = IntVar()

mb.menu.add_checkbutton (label="mayo",
                          variable=mayoVar )
mb.menu.add_checkbutton (label="ketchup",
                          variable=ketchVar )

# mb.pack()
mb.grid(column=1, row=0, sticky=NE, padx=0, pady=0)
top.mainloop()