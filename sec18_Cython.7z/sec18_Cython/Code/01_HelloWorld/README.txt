# https://cython.readthedocs.io/en/latest/src/tutorial/cython_tutorial.html#the-basics-of-cython
1. > conda install Cython
2. Create a file: hellowworld.pyx
   > print("Hello World")
3. Create setup.py
   > from setuptools import setup
   > from Cython.Build import cythonize

   > setup(
   >   ext_modules = cythonize("helloworld.pyx")
   > )
4. > python setup.py build_ext --inplace
5. > python
   >> import helloworld
   >>> Hello World