# https://cython.readthedocs.io/en/latest/src/tutorial/cython_tutorial.html#the-basics-of-cython
1. conda install Cython
2. Create primes.pyx
def primes(int nb_primes):
    cdef int n, i, len_p
    cdef int p[1000]

    if nb_primes > 1000:
        nb_primes = 1000




    len_p = 0  # The current number of elements in p.
    n = 2
    while len_p < nb_primes:
        # Is n prime?
        for i in p[:len_p]:
            if n % i == 0:
                break

        # If no break occurred in the loop, we have a prime.
        else:
            p[len_p] = n
            len_p += 1
        n += 1

    # Let's copy the result into a Python list:
    result_as_list = [prime for prime in p[:len_p]]
    return result_as_list
3. Create setup.py
from setuptools import setup
from Cython.Build import cythonize

setup(
    ext_modules=cythonize("primes.pyx"),
)

4. > python setup.py build_ext --inplace

5. python 
>>> import primes
>>> primes.primes(5)
[2, 3, 5, 7, 11]
>>> primes.primes(1)
[2]
>>> primes.primes(2)
[2, 3]
>>> primes.primes(3)
[2, 3, 5]
>>> primes.primes(4)
[2, 3, 5, 7]