#import example_cy
#example_cy.test(5)
import timeit
cy = timeit.timeit ('example_cy.test(5)', setup='import example_cy', number = 100)
py = timeit.timeit ('example_py.test(5)', setup='import example_py', number = 100)
print('cy:', cy, 'py:', py)
print('Cython is {} x faster'.format (py/cy))