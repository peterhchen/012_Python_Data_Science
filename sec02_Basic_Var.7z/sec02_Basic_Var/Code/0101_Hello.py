print ("Hello, Python!")
