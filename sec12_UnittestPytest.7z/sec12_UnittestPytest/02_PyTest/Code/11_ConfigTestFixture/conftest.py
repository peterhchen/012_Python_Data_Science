import pytest

@pytest.fixture
def input_value():
   input = 39
   return input