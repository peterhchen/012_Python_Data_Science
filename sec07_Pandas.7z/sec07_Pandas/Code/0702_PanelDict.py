#creating an empty panel
import pandas as pd
import numpy as np

#data = {'Item1' : pd.DataFrame(np.random.randn(4, 3)), 
#   'Item2' : pd.DataFrame(np.random.randn(4, 2))}  
#p = pd.Panel(data)
#Panel deprecated.
#print (p)
# https://stackoverflow.com/questions/13575090/construct-pandas-dataframe-from-items-in-nested-dictionary
user_dict = {12: {'Category 1': {'att_1': 1, 'att_2': 'whatever'},
                  'Category 2': {'att_1': 23, 'att_2': 'another'}},
             15: {'Category 1': {'att_1': 10, 'att_2': 'foo'},
                  'Category 2': {'att_1': 30, 'att_2': 'bar'}}}

df = pd.DataFrame.from_dict({(i,j): user_dict[i][j] 
                           for i in user_dict.keys() 
                           for j in user_dict[i].keys()},
                       orient='index')

print('df:')
print(df)