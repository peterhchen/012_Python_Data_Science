"""
File Name: 1000_DataFrameDrop.py
https://www.tutorialspoint.com/python-remove-the-missing-nan-values-in-the-dataframe
"""

import pandas as pd

# reading csv file
DATA_FRAME = pd.read_csv("./CarRecord.csv")
print("DataFrame with some NaN (missing) values...\n", DATA_FRAME)

# count the rows and columns in a DataFrame
print("\nNumber of rows and column in our DataFrame = ", DATA_FRAME.shape)

# drop the missing values
#df=dataFrame.dropna()
#print("\nDataFrame after removing NaN values...\n",df)
print("\nDataFrame after removing NaN values...\n", DATA_FRAME.dropna())

#DataFrame with some NaN (missing) values...
#            Car       Place  UnitsSold
#0         Audi   Bangalore       80.0
#1      Porsche      Mumbai        NaN
#2   RollsRoyce        Pune      100.0
#3          BMW       Delhi        NaN
#4     Mercedes   Hyderabad       80.0
#5  Lamborghini  Chandigarh       80.0
#6         Audi      Mumbai        NaN
#7     Mercedes        Pune      120.0
#8  Lamborghini       Delhi      100.0
#
#Number of rows and column in our DataFrame =  (9, 3)
#
#DataFrame after removing NaN values...
#            Car       Place  UnitsSold
#0         Audi   Bangalore       80.0
#2   RollsRoyce        Pune      100.0
#4     Mercedes   Hyderabad       80.0
#5  Lamborghini  Chandigarh       80.0
#7     Mercedes        Pune      120.0
#8  Lamborghini       Delhi      100.0
