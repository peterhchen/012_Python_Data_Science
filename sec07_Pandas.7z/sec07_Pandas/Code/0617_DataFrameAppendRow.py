import pandas as pd

df = pd.DataFrame([[1, 2], [3, 4]], columns = ['a','b'])
df2 = pd.DataFrame([[5, 6], [7, 8]], columns = ['a','b'])
print('orignal row df:')
print(df)
print()
print('Append new df2:')
print(df2)
print()
df = df.append(df2)
print('Final df:')
print(df)