#import the pandas library and aliasing as pd
import pandas as pd
# Old way: empty is float64.
# s = pd.Series ()
# print('s:', s)
# 0501_CreateSeries.py:3: DeprecationWarning: The default dtype for 
# empty Series will be 'object' instead of 'float64' in a future version. 
# Specify a dtype explicitly to silence this warning.
#  s = pd.Series ()
# s: Series([], dtype: float64)

# new way: empty is 'object'
df = pd.DataFrame.empty
s = pd.Series (df)
print('s:', s)
# s: 0    <property object at 0x0000022E02263908>
# dtype: object